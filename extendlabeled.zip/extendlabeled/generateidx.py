import glob
import random
import os
pdir=r'.\particle\*.bmp'
npdir=r'.\nonparticle\*.bmp'
newpdir=r'.\newparticle\*.bmp'
newnpdir=r'.\newnonparticle\*.bmp'

particlefiles=glob.glob(pdir)+glob.glob(newpdir)
random.shuffle(particlefiles)
nonparticlefiles=glob.glob(npdir)+glob.glob(newnpdir)
random.shuffle(nonparticlefiles)

labeltxt='./labels.txt'
print(len(particlefiles),len(nonparticlefiles))
with open(labeltxt,'w') as f:
    for i in range(len(particlefiles)):
        s1='{},{}\n'.format(os.path.abspath(particlefiles[i]),'1')
        s2='{},{}\n'.format(os.path.abspath(nonparticlefiles[i]),'0')
        f.write(s1)
        f.write(s2)
f.close()

